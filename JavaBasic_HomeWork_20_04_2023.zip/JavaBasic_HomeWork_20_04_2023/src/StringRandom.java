/*
1 уровень сложности: Напишите аналог Random для
генерации строк - StringRandom. В классе реализуйте набор
 публичных статических методов: первый метод генерирует
 слово заданной длины, состоящее из  английских букв
 (любой набор букв). Второй метод генерирует предложение из заданного
  количества разных слов. Третий метод генерирует текст из заданного
  количества разных предложений, разделяя предложения случайными
   знаками препинания из набора (. или ! или ? или …).
   В методе main сгенерируйте текст из 1000 предложений.

 */

import java.util.Random;

public class StringRandom {
    private static final Random random = new Random();
    private static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";

    public static String generateRandomWord(int length) {
        StringBuilder word = new StringBuilder();
        for (int i = 0; i < length; i++) {
            char randomChar = ALPHABET.charAt(random.nextInt(ALPHABET.length()));
            word.append(randomChar);
        }
        return word.toString();
    }

    public static String generateRandomSentence(int wordCount) {
        StringBuilder sentence = new StringBuilder();
        for (int i = 0; i < wordCount; i++) {
            if (i > 0) {
                sentence.append(" ");
            }
            sentence.append(generateRandomWord(random.nextInt(5) + 1)); // Генерируем слова длиной от 1 до 5 символов
        }
        sentence.append(randomPunctuation());
        return sentence.toString();
    }

    public static String generateRandomText(int sentenceCount) {
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < sentenceCount; i++) {
            if (i > 0) {
                text.append(" ");
            }
            text.append(generateRandomSentence(random.nextInt(10) + 1)); // Генерируем предложения от 1 до 10 слов
        }
        return text.toString();
    }

    private static char randomPunctuation() {
        char[] punctuation = {'.', '!', '?', '…'};
        return punctuation[random.nextInt(punctuation.length)];
    }

    public static void main(String[] args) {
        // Генерируем текст из 1000 предложений
        String randomText = generateRandomText(1000);
        System.out.println(randomText);
    }
}